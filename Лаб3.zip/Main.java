
import java.util.ArrayList;


public class Main {
    public static void main(String[] args) {
        ArrayList<Person> peopleArray = new ArrayList<Person>();
        peopleArray.add(new Person(0, "Aboba", "Mykhailo", "Mykhailovych", "5 Zelena St.", "380635086549"));
        peopleArray.add(new Abiturient(1, "Ivanov", "Ivan", "Ivanovych", "76 Bandery St.", "+380505555555", 4.5));
        peopleArray.add(new Student(3, "Zhukevych", "Vitalii", "Romanovych", "23 Lvivska St.", "+3805055543754", "ITMT", 4, "KI-406"));
        peopleArray.add(new Abiturient(3, "Dmitruk", "Dmitro", "Dmitrykovych", "1 Ternopilska St.", "+380501111111", 4.7));
        for(Object i:peopleArray){
            System.out.println(i.toString());
        }
    }
}