public class Student extends Person {
    private String faculty;
    private int course;
    private String group;

    public Student(int id , String lastName , String firstName , String middleName , String address , String phone, String faculty, int course, String group) {
        super(id , lastName , firstName , middleName , address , phone);
        this.faculty = faculty;
        this.course = course;
        this.group = group;
    }
    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public int getCourse() {
        return course;
    }

    public void setCourse(int course) {
        this.course = course;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    @Override
    public String toString() {
        return "Student(" +
                "[id=" + getId() +
                "], [lastName='" + getLastName() + '\'' +
                "], [firstName='" + getFirstName() + '\'' +
                "], [middleName='" + getMiddleName() + '\'' +
                "], [address='" + getAddress() + '\'' +
                "], [phone='" + getPhone() + '\'' +
                "], [faculty='" + getGroup() + '\'' +
                "], [course=" + getCourse() +
                "], [group='" + getFaculty() + '\'' +
                "])";
    }
}
