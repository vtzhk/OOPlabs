public class Abiturient extends Person{
    private double avgGrade;

    public Abiturient(int id , String lastName , String firstName , String middleName , String address , String phone, double avgGrade) {
        super(id , lastName , firstName , middleName , address , phone);
        this.avgGrade = avgGrade;
    }

    public double getAvgGrade() {
        return avgGrade;
    }

    public void setAvgGrade(double avgGrade) {
        this.avgGrade = avgGrade;
    }

    @Override
    public String toString() {
        return "Abiturient(" +
                "[id=" + getId() +
                "], [lastName='" + getLastName() + '\'' +
                "], [firstName='" + getFirstName() + '\'' +
                "], [middleName='" + getMiddleName() + '\'' +
                "], [address='" + getAddress() + '\'' +
                "], [phone='" + getPhone() + '\'' +
                "], [avgGrade=" + getAvgGrade() +
                "])";
    }
}